@extends('admin.layouts.main')

@section('content')
@php
$visatype  = config('wallet.visaType');
$resource = config('wallet.resource');
$jstatus = config('wallet.cstatus');

@endphp
<div class="container-fluid">
    <div class="card">               
        <div class="card-body">
            <h2>Update Daily Report</h2>
            <form action="{{ url('admin/userreports/'.$journal->reportId) }}" id="addUser" method="post" >
                <div class="row">
                    {{ method_field('PUT') }}
                    {{ csrf_field() }}
                
                    
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="consultatName">Consultant Name:</label>
                            <input type="text" class="form-control {{ $errors->has('consultatName') ? ' is-invalid' : '' }}" id="cname" placeholder="Enter Consultant Name" name="consultatName" required value="{{$journal->consultatName}}">
                            <div class="invalid-feedback">{{ $errors->first('consultatName')  }}</div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="consultantEmail">Consultant Email:</label>
                            <input type="email" class="form-control {{ $errors->has('consultantEmail') ? ' is-invalid' : '' }}" id="consultantEmail" placeholder="Enter Consultant Email" name="consultantEmail" required value="{{$journal->consultantEmail}}">
                            <div class="invalid-feedback">{{ $errors->first('consultantEmail')  }}</div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="consultatMobileNumber">Consultant Mobile:</label>
                            <input type="text" class="phone_us form-control {{ $errors->has('consultatMobileNumber') ? ' is-invalid' : '' }}" id="consultatMobileNumber" placeholder="Enter Consultant Mobile" name="consultatMobileNumber" required value="{{$journal->consultatMobileNumber}}">
                            <div class="invalid-feedback">{{ $errors->first('consultatMobileNumber')  }}</div>
                        </div>
                    </div>
                      <div class="col-lg-3">
                        <div class="form-group">
                            <label for="technology">Technology:</label>
                            <input type="text" class="form-control {{ $errors->has('technology') ? ' is-invalid' : '' }}" id="technology" placeholder="Technology" name="technology" required value="{{$journal->technology}}">
                            <div class="invalid-feedback">{{ $errors->first('technology')  }}</div>
                        </div>
                    </div>
                </div>
                <div class="row">
                      <div class="col-lg-2">
                        <div class="form-group">
                            <label for="rate">Expected Rate:</label>
                            <input type="text" class="form-control {{ $errors->has('rate') ? ' is-invalid' : '' }}" id="rate" placeholder="Rate" name="rate" required value="{{$journal->rate}}">
                            <div class="invalid-feedback">{{ $errors->first('rate')  }}</div>
                        </div>
                    </div>
                      <div class="col-lg-2">
                        <div class="form-group">
                            <label for="experience">Experience:</label>
                            <input type="text" class="form-control {{ $errors->has('experience') ? ' is-invalid' : '' }}" id="experience" placeholder="Experience" name="experience"  required value="{{$journal->experience}}">
                            <div class="invalid-feedback">{{ $errors->first('experience')  }}</div>
                        </div>
                    </div>
                  
                     <div class="col-lg-2">
                        <div class="form-group">
                            <label for="visaType">Visa Type:</label>

                            <select class="form-control {{ $errors->has('visaType') ? ' is-invalid' : '' }}" required name="visaType" id="visaType">
                                <option value="">--select--</option>
                                @foreach ($visatype as $key => $value)
                            <option value="{{$key}}" {{($journal->visaType == $key) ? "selected" : "" }}>{{$value}}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback">{{ $errors->first('visaType')  }}</div>
                        </div>
                    </div>
                        <div class="col-lg-2">
                        <div class="form-group">
                            <label for="city">City:</label>
                            <input type="text" class="form-control {{ $errors->has('city') ? ' is-invalid' : '' }}" id="city" placeholder="City" name="city" required value="{{$journal->city}}">
                            <div class="invalid-feedback">{{ $errors->first('city')  }}</div>
                        </div>
                    </div>
                       <div class="col-lg-2">
                        <div class="form-group">
                            <label for="state">State:</label>
                            <input type="text" class="form-control {{ $errors->has('state') ? ' is-invalid' : '' }}" id="state" placeholder="State" name="state" required value="{{$journal->state}}">
                            <div class="invalid-feedback">{{ $errors->first('state')  }}</div>
                        </div>
                    </div>
                     <div class="col-lg-2">
                        <div class="form-group">
                            <label for="willingLocation">Willing to Reloacate:</label>
                             
                            <select class="form-control {{ $errors->has('willingLocation') ? ' is-invalid' : '' }}" required name="willingLocation" id="willingLocation">
                                <option value="">--select--</option>
                            <option value="yes" {{($journal->willingLocation == "yes") ? "selected" : "" }}>Yes</option>
                               <option value="no" {{($journal->willingLocation == "no") ? "selected" : "" }}>No</option>
                            </select>
                            <div class="invalid-feedback">{{ $errors->first('willingLocation')  }}</div>
                        </div>
                    </div>
                </div>
                <div class="row">
                     <div class="col-lg-2">
                        <div class="form-group">
                            <label for="documentsCollected">Documents collected:</label>
                             
                            <select class="form-control"  name="documentsCollected" required id="">
                                <option value="">--select--</option>
                            <option value="yes" {{($journal->documentsCollected == "yes") ? "selected" : "" }}>Yes</option>
                               <option value="no" {{($journal->documentsCollected == "no") ? "selected" : "" }}>No</option>
                            </select>
                            <div class="invalid-feedback">{{ $errors->first('documentsCollected')  }}</div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="form-group">
                            <label for="resource">Resource:</label>

                            <select class="form-control {{ $errors->has('resource') ? ' is-invalid' : '' }}" 
                                name="resource" id="resource">
                                <option value="">--select--</option>
                                @foreach ($resource as $key => $value)
                                <option value="{{$key}}" {{($journal->resource == $key) ? "selected" : "" }}>{{$value}}
                                </option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback">{{ $errors->first('resource')  }}</div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                    <div class="form-group">
                            <label for="status">Status:</label>

                            <select class="form-control {{ $errors->has('status') ? ' is-invalid' : '' }}" required name="status" id="status">
                                 <option value="">--select--</option>
                                @foreach ($jstatus as $key => $value)
                            <option value="{{$key}}" {{($journal->reportStatus == $key) ? "selected" : "" }}>{{$value}}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback">{{ $errors->first('status')  }}</div>
                        </div>
                </div>

                     <div class="col-lg-6">
                        <div class="form-group">
                            <label for="comments">Comments:</label>
                            <textarea class="form-control {{ $errors->has('comments') ? ' is-invalid' : '' }}" id="comments"  name="comments"  value="{{old('comments')}}">{{$journal->comments}}</textarea>
                          
                            <div class="invalid-feedback">{{ $errors->first('comments')  }}</div>
                        </div>
                    </div>  
                      <div class="col-lg-12">
                        <div class="form-group">
                            <p>&nbsp;</p>
                            <button type="submit" class="btn btn-primary float-right" id="submitForm"><i class="fa fa-plus"></i> Edit Consultant Details</button>
                        </div>
                    </div>               
                  
                </div>
             </form>
            </div>
        </div>  
</div>
@endsection

@section('jQeryValidationJs')
@include('admin.layouts.validationjs');
@endsection

@section('addonJsScript')
<script type="text/javascript">
    $(document).ready(function () {
        $("#addUser").validate({
             rules: {
                name: {
                    required: true,
                    minlength: 4
                },
                email: {
                    required: true,
                    email: true
                },               
                userType: "required",
                 source: "required",
                  countryId: "required",
                   status: "required",
                   mobilenumber:{
                              required:true,
                               number:true,
                              minlength:9,
                              maxlength:10,
                            
                         },
            },
            messages: {
                name: {
                    required: "Please enter Name",
                    minlength: "Name must consist of at least 4 characters"
                },
                email: {
                    required: "Please enter Email Address",
                    email: "Please enter valid Email Address"
                },
               
                userType: "Please choose journal type",
                source : "Please choose Register Source",
                countryId : "Please choose Country",
                  mobilenumber : {
                              required:"Enter Mobile Number",
                               number : "Enter only Digits",
                              minlength: "Min 9 digits",
                              maxlength:"Max 10 digits",
                             
                  }

            },
            errorElement: "em",
            errorPlacement: function (error, element) {
                // Add the `invalid-feedback` class to the error element
                error.addClass("invalid-feedback");
                if (element.prop("type") === "checkbox") {
                    error.insertAfter(element.next("label"));
                } else {
                    error.insertAfter(element);
                }
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass("is-invalid").removeClass("is-valid");
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).addClass("is-valid").removeClass("is-invalid");
            }
        });
    });
</script>
@endsection