@extends('admin.layouts.main')

@section('content')
@php
$i  = 1 + (1 * (($users->currentPage() * config('wallet.resultsPerPage')) - config('wallet.resultsPerPage')));

$visatype  = config('wallet.visaType');
$status = config('wallet.rstatus');
@endphp
<div class="container-fluid">
    @if (session('message'))
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Success!</strong> {{ session('message') }}
    </div>    
    @endif
    <div class="row">
        <div class="col-lg-12">
            <h2 class="text-center">Consultants Daily Reports</h2>
        </div>
      
       
    </div>   
      
 <!--   <form  action="{{ url('admin/userreports/') }}" method="get" autocomplete="off">
        {{ csrf_field() }}
        <div class="form-group row">
            <div class="col-lg-2">
                <label for="name"> Name:</label>
                <input type="text" value="{{request()->get('name')}}" class="autocomplete form-control" id="name" name="name">
            </div>
          
            
            <div class="col-lg-3">
                <label for="user_status">Status:</label>
                <select class="form-control" name="user_status" id="user_status">
                    <option value="">-- Select Status --</option>
                    @foreach($status as $key => $value)
                    <option value="{{$key}}"  {{(request()->get('user_status') == $key) ? 'selected' : '' }}>{{$value}}</option>                  
                    @endforeach
                </select>
            </div>
            <div class="col-lg-1">               
                <label for="submit">&nbsp;</label><br/>
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
            <div class="col-lg-1">               
                <label for="submit">&nbsp;</label><br/>
                <button type="button" id="reset-btn" class="btn btn-primary">Clear</button>
            
            </div>
        </div>
    </form> -->

    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>S.No</th>
                       <th>Date</th>
                    <th>Consultant Name</th>
                    <th>Vendor Status</th>  
                    <th>Phone number</th>   

                    <th>Technology </th>     
                    <th>Rate</th>     
                    <th>Visa Type</th>     
                    <th>City</th>     
                    <th>State</th>     
                    <th>Experience</th>   
                    <th>Willing to Relocate</th>    
                    <th>Status</th>     
                    <th>Comments</th>                  
                    <th>Actions</th>
                </tr>
            </thead>
            <tfoot>
               
            </tfoot>
            <tbody>
         
                @foreach ($users as $journal)
              @php
               $url=url('admin/vendors/'.$journal->vendorId.'/edit');
                @endphp
                <tr>
                    <td>{{ $i }}</td>
                   <td>{{ \Carbon\Carbon::parse($journal->reportDate)->format('d/m/Y h:i:sa') }}</td>
                     <td>{{ $journal->consultatName }}</td>
                     <th>{{ ($journal->vendorName?'Added':'  -  ') }}
                        </th>
                       <td>{{ $journal->consultatMobileNumber }}</td>
                         <td>{{ $journal->technology }}</td>
                           <td>{{ $journal->rate }}</td>                            
                               <td>{{ $journal->visaType }}</td>
                                 <td>{{ $journal->city }}</td>
                                   <td>{{ $journal->state }}</td>
                                    <td>{{ $journal->experience }}</td>
                                    
                                           <td>{{ $journal->willingLocation}}</td>
                                           <td>{{ $journal->reportStatus }}</td>
                    <td>{{ $journal->comments }}</td>
                   
                    <td>
                        @if( $journal->reportStatus === 'C' )
                      <!--  <a href="{{ $journal->reportId.'/B' }}" class="btn btn-circle btn-sm btn-danger updateStatus" data-toggle="tooltip" title="Block Journal"><i class="fa fa-thumbs-down"></i></a> 
                        <a href="{{\url('admin/userreports/'.$journal->reportId.'/edit')}}" class="btn btn-circle btn-sm btn-success" data-toggle="tooltip" title="Edit Journal Info"><i class="fa fa-magic"></i></a>
                               <a href="{{ $journal->reportId.'/A' }}" class="btn btn-circle btn-sm btn-primary updateStatus" data-toggle="tooltip" title="Activate Report"><i class="fa fa-thumbs-up"></i></a> -->
                        <a>Closed</a> 
                        @else
                 
                         <a href="{{\url('admin/userreports/'.$journal->reportId.'/edit')}}" class="btn btn-circle btn-sm btn-primary" data-toggle="tooltip" title="Edit Daily Report "><i class="fa fa-magic"></i></a> 
                        @endif
                    </td>
                </tr>
                @php $i++ @endphp
                @endforeach
            </tbody>
        </table>
        {{ $users->links() }}
    </div>
</div>
@endsection

@section('addonJsScript')
<script src="{{ asset('dashboard/js/common.js')}}"></script>        

<script type="text/javascript">


       $(document).ready(function () {
        $('.updateStatus').click(function (e) {
            e.preventDefault();
            console.log($(this).attr('href'));
            var input = $(this).attr('href').split("/");
            console.log(input);

            var status = 'Active';

            if (input[1] == 'B') {
                status = 'Block';
            }

            swal({
                title: "User going to " + status + ' Journal',
                text: "Submit to update Status",
                type: "warning",
                showCancelButton: true,
                closeOnConfirm: false,
                showLoaderOnConfirm: true
            }, function () {
                var url = '{{url("api/updateJournalStatus")}}';
                var type = 'post';

                var data = {
                    'id': input[0],
                    'status': input[1],
                    '_token': '{{ csrf_token() }}'
                };
                var headers = {
                    '_token': '{{ csrf_token() }}',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                };
                var result = ajaxRequest(url, type, data, headers);
               
            });
        });
       
    });
   $( "#reset-btn" ).click(function() {
         $('#name').val('').change();
    
      $('#user_status').val('').change();
    
    
    });
    
</script>
@endsection