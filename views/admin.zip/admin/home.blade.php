@extends('admin.layouts.main')

@section('content')
    <div class="container-fluid">
        @if (session('message'))
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Success!</strong> {{ session('message') }}
            </div>
        @endif
        <style type="text/css">
            .dash-head:hover {
                text-decoration: none !important;
            }
        </style>
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        </div>
        <div class="row">

        </div>
        <hr/>
    </div>
@endsection
@section('addonJsScript')
    <script src="{{ asset("dashboard/js/common.js")}}"></script>

    <script type="text/javascript">

        $(document).ready(function () {

            $('.updateStatus').click(function (e) {
                e.preventDefault();
                console.log($(this).attr('href'));
                var input = $(this).attr('href').split("/");
                console.log(input);

                var status = 'Active';

                if (input[1] == 'B') {
                    status = 'Block';
                }

                swal({
                    title: "User going to " + status + ' Customer',
                    text: "Submit to update Status",
                    type: "warning",
                    showCancelButton: true,
                    closeOnConfirm: false,
                    showLoaderOnConfirm: true
                }, function () {
                    var url = '{{url("api/updateCustomerStatus")}}';
                    var type = 'post';

                    var data = {
                        'id': input[0],
                        'status': input[1],
                        '_token': '{{ csrf_token() }}'
                    };
                    var headers = {
                        '_token': '{{ csrf_token() }}',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    };
                    var result = ajaxRequest(url, type, data, headers);
                });
            });
        });
    </script>
@endsection